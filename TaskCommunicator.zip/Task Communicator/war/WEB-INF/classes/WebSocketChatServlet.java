import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;
import org.eclipse.jetty.websocket.*;

public class WebSocketChatServlet extends WebSocketServlet {
  public final Set users=new CopyOnWriteArraySet();

/*
  public void init() throws ServletException {
    ServletContext sc=getServletContext();

    if(sc.getAttribute("CommunicationContainer")==null)
      sc.setAttribute("CommunicationContainer", new CommunicationContainer());
  }
*/

  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  }

  public WebSocket doWebSocketConnect(HttpServletRequest arg0, String arg1) {
    ServletContext sc=getServletContext();

    CommunicationContainer cContainer=null;

    Object objContainer=sc.getAttribute("CommunicationContainer");

    if(objContainer==null) {
      cContainer=new CommunicationContainer();

      sc.setAttribute("CommunicationContainer", cContainer);
    }
    else {
      cContainer=(CommunicationContainer)objContainer;
    }

    return new ChatWebSocket(users, cContainer);
  }
}