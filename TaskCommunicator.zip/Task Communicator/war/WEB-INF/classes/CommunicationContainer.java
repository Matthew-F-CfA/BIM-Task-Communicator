import java.util.Vector;
import java.util.TreeMap;

public class CommunicationContainer {
  public static int BASE_HISTORY=0;
  public static int BASE_CURRENT=1;
  public static int WORKER_HISTORY=2;
  public static int WORKER_CURRENT=3;

  public static int MAX_MESSAGES=10000;

  volatile Vector vecBaseHistory=new Vector();
  volatile TreeMap hashBaseHistory=new TreeMap();
  volatile Vector vecBaseCurrent=new Vector();
  volatile TreeMap hashBaseCurrent=new TreeMap();
  volatile Vector vecWorkerHistory=new Vector();
  volatile TreeMap hashWorkerHistory=new TreeMap();
  volatile Vector vecWorkerCurrent=new Vector();
  volatile TreeMap hashWorkerCurrent=new TreeMap();

  volatile long lngMessageID=0l;

  public volatile Object objSync=new Object();

  CommunicationContainer() {
  }

  public Vector getVecBaseHistory() {
    return vecBaseHistory;
  }

  public void setVecBaseHistory(Vector vecBaseHistory) {
    this.vecBaseHistory=vecBaseHistory;
  }

  public TreeMap getHashBaseHistory() {
    return hashBaseHistory;
  }

  public void setHashBaseHistory(TreeMap hashBaseHistory) {
    this.hashBaseHistory=hashBaseHistory;
  }

  public Vector getVecBaseCurrent() {
    return vecBaseCurrent;
  }

  public void setVecBaseCurrent(Vector vecBaseCurrent) {
    this.vecBaseCurrent=vecBaseCurrent;
  }

  public TreeMap getHashBaseCurrent() {
    return hashBaseCurrent;
  }

  public void setHashBaseCurrent(TreeMap hashBaseCurrent) {
    this.hashBaseCurrent=hashBaseCurrent;
  }

  public Vector getVecWorkerHistory() {
    return vecWorkerHistory;
  }

  public void setVecWorkerHistory(Vector vecWorkerHistory) {
    this.vecWorkerHistory=vecWorkerHistory;
  }

  public TreeMap getHashWorkerHistory() {
    return hashWorkerHistory;
  }

  public void setHashWorkerHistory(TreeMap hashWorkerHistory) {
    this.hashWorkerHistory=hashWorkerHistory;
  }

  public Vector getVecWorkerCurrent() {
    return vecWorkerCurrent;
  }

  public void setVecWorkerCurrent(Vector vecWorkerCurrent) {
    this.vecWorkerCurrent=vecWorkerCurrent;
  }

  public TreeMap getHashWorkerCurrent() {
    return hashWorkerCurrent;
  }

  public void setHashWorkerCurrent(TreeMap hashWorkerCurrent) {
    this.hashWorkerCurrent=hashWorkerCurrent;
  }

  public String addMessage(String strMessage, int intAddID) {
    String strMessageID="";

synchronized(objSync) {

    strMessageID=String.valueOf(lngMessageID);

    if(intAddID==BASE_HISTORY) {
      vecBaseHistory.addElement(new Long(lngMessageID));
      hashBaseHistory.put(new Long(lngMessageID), strMessage);

      if(vecBaseHistory.size()>MAX_MESSAGES) {
        Long lngExpiredMessageID=(Long)vecBaseHistory.elementAt(0);

        hashBaseHistory.remove(lngExpiredMessageID);
      }
    }
    else if(intAddID==BASE_CURRENT) {
      vecBaseCurrent.addElement(new Long(lngMessageID));
      hashBaseCurrent.put(new Long(lngMessageID), strMessage);

      if(vecBaseCurrent.size()>MAX_MESSAGES) {
        Long lngExpiredMessageID=(Long)vecBaseCurrent.elementAt(0);

        hashBaseCurrent.remove(lngExpiredMessageID);
      }
    }
    else if(intAddID==WORKER_HISTORY) {
      vecWorkerHistory.addElement(new Long(lngMessageID));
      hashWorkerHistory.put(new Long(lngMessageID), strMessage);

      if(vecWorkerHistory.size()>MAX_MESSAGES) {
        Long lngExpiredMessageID=(Long)vecWorkerHistory.elementAt(0);

        hashWorkerHistory.remove(lngExpiredMessageID);
      }
    }
    else if(intAddID==WORKER_CURRENT) {
      vecWorkerCurrent.addElement(new Long(lngMessageID));
      hashWorkerCurrent.put(new Long(lngMessageID), strMessage);

      if(vecWorkerCurrent.size()>MAX_MESSAGES) {
        Long lngExpiredMessageID=(Long)vecWorkerCurrent.elementAt(0);

        hashWorkerCurrent.remove(lngExpiredMessageID);
      }
    }

    lngMessageID+=1l;

}

    return strMessageID;
  }

  public void removeMessage(String strMessageID, int intRemoveID) {
synchronized(objSync) {

    long lngRemoveMessageID=0l;
    try {
      lngRemoveMessageID=Long.valueOf(strMessageID).longValue();
    }
    catch(Exception ex) {
      return;
    }

    Vector vecRemove=null;
    TreeMap hashRemove=null;

    if(intRemoveID==BASE_HISTORY) {
      vecRemove=vecBaseHistory;
      hashRemove=hashBaseHistory;
    }
    else if(intRemoveID==BASE_CURRENT) {
      vecRemove=vecBaseCurrent;
      hashRemove=hashBaseCurrent;
    }
    else if(intRemoveID==WORKER_HISTORY) {
      vecRemove=vecWorkerHistory;
      hashRemove=hashWorkerHistory;
    }
    else if(intRemoveID==WORKER_CURRENT) {
      vecRemove=vecWorkerCurrent;
      hashRemove=hashWorkerCurrent;
    }

    for(int i=0;i<vecRemove.size();i++) {
      long lngNextID=((Long)vecRemove.elementAt(i)).longValue();

      if(lngNextID==lngRemoveMessageID) {
        hashRemove.remove(new Long(lngNextID));
        vecRemove.removeElementAt(i);

        break;
      }
    }

}
  }

  public String transferMessage(String strMessageID, int intTransferFromID, int intTransferToID) throws Exception {
    String strMessage="";

synchronized(objSync) {

    long lngTransferMessageID=0l;
    try {
      lngTransferMessageID=Long.valueOf(strMessageID).longValue();
    }
    catch(Exception ex) {
      throw new Exception("Message ID is not a long.");
    }

    Vector vecTransferFrom=null;
    TreeMap hashTransferFrom=null;

    Vector vecTransferTo=null;
    TreeMap hashTransferTo=null;

    if(intTransferFromID==BASE_HISTORY) {
      vecTransferFrom=vecBaseHistory;
      hashTransferFrom=hashBaseHistory;
    }
    else if(intTransferFromID==BASE_CURRENT) {
      vecTransferFrom=vecBaseCurrent;
      hashTransferFrom=hashBaseCurrent;
    }
    else if(intTransferFromID==WORKER_HISTORY) {
      vecTransferFrom=vecWorkerHistory;
      hashTransferFrom=hashWorkerHistory;
    }
    else if(intTransferFromID==WORKER_CURRENT) {
      vecTransferFrom=vecWorkerCurrent;
      hashTransferFrom=hashWorkerCurrent;
    }

    if(intTransferToID==BASE_HISTORY) {
      vecTransferTo=vecBaseHistory;
      hashTransferTo=hashBaseHistory;
    }
    else if(intTransferToID==BASE_CURRENT) {
      vecTransferTo=vecBaseCurrent;
      hashTransferTo=hashBaseCurrent;
    }
    else if(intTransferToID==WORKER_HISTORY) {
      vecTransferTo=vecWorkerHistory;
      hashTransferTo=hashWorkerHistory;
    }
    else if(intTransferToID==WORKER_CURRENT) {
      vecTransferTo=vecWorkerCurrent;
      hashTransferTo=hashWorkerCurrent;
    }


    boolean blnFoundIt=false;
    for(int i=0;i<vecTransferFrom.size();i++) {
      long lngNextID=((Long)vecTransferFrom.elementAt(i)).longValue();

      if(lngNextID==lngTransferMessageID) {
        blnFoundIt=true;

        strMessage=(String)hashTransferFrom.remove(new Long(lngNextID));
        vecTransferFrom.removeElementAt(i);

        vecTransferTo.addElement(new Long(lngNextID));
        hashTransferTo.put(new Long(lngNextID), strMessage);

        break;
      }
    }

    if(!blnFoundIt)
      throw new Exception("No such ID found.");

}

    return strMessage;
  }
}