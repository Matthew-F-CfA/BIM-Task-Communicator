import org.eclipse.jetty.websocket.*;
import java.util.*;

public class ChatWebSocket implements WebSocket.OnTextMessage {
  private Connection connection;
  private Set users;
  CommunicationContainer cContainer;

  public ChatWebSocket(Set users, CommunicationContainer cContainer) {
    this.users=users;
    this.cContainer=cContainer;
  }

  public void onMessage(String data) {
    if(data.startsWith("worker")) {
      data=data.substring(6);

      String strID=cContainer.addMessage(data, CommunicationContainer.WORKER_CURRENT);
      data=strID+": "+data;

      data="workerCurrent"+"message"+data;
    }
    else if(data.startsWith("base")) {
      data=data.substring(4);

      String strID=cContainer.addMessage(data, CommunicationContainer.BASE_CURRENT);
      data=strID+": "+data;

      data="baseCurrent"+"message"+data;
    }
    else if(data.startsWith("remove")) {
synchronized(cContainer.objSync) {

      data=data.substring(6);

      String strRemove=null;
      Vector vecRemove=null;
      TreeMap hashRemove=null;

      if(data.startsWith("baseHistory")) {
        data=data.substring(11);

        cContainer.removeMessage(data, CommunicationContainer.BASE_HISTORY);

        strRemove="baseHistory";
        vecRemove=cContainer.getVecBaseHistory();
        hashRemove=cContainer.getHashBaseHistory();
      }
      else if(data.startsWith("baseCurrent")) {
        data=data.substring(11);

        cContainer.removeMessage(data, CommunicationContainer.BASE_CURRENT);

        strRemove="baseCurrent";
        vecRemove=cContainer.getVecBaseCurrent();
        hashRemove=cContainer.getHashBaseCurrent();
      }
      else if(data.startsWith("workerHistory")) {
        data=data.substring(13);

        cContainer.removeMessage(data, CommunicationContainer.WORKER_HISTORY);

        strRemove="workerHistory";
        vecRemove=cContainer.getVecWorkerHistory();
        hashRemove=cContainer.getHashWorkerHistory();
      }
      else if(data.startsWith("workerCurrent")) {
        data=data.substring(13);

        cContainer.removeMessage(data, CommunicationContainer.WORKER_CURRENT);

        strRemove="workerCurrent";
        vecRemove=cContainer.getVecWorkerCurrent();
        hashRemove=cContainer.getHashWorkerCurrent();
      }

      Vector vecMessages=new Vector();
      for(int i=0;i<vecRemove.size();i++) {
        Object objNext=vecRemove.elementAt(i);
        vecMessages.addElement(hashRemove.get(objNext));
      }

      Iterator iter=users.iterator();
      while(iter.hasNext()) {
        ChatWebSocket user=(ChatWebSocket)iter.next();

        try {
          user.connection.sendMessage(strRemove+"clear");

          for(int i=0;i<vecRemove.size();i++) {
            Object objNext=vecRemove.elementAt(i);
            user.connection.sendMessage(strRemove+"message"+String.valueOf(objNext)+": "+String.valueOf(vecMessages.elementAt(i)));
          }
        }
        catch(Exception ex) {
        }
      }

}

      return;
    }
    else if(data.startsWith("transfer")) {
synchronized(cContainer.objSync) {

      data=data.substring(8);

      String strRemove=null;
      Vector vecRemove=null;
      TreeMap hashRemove=null;

      String strAdd=null;

      int intTransferFromID=-1;
      int intTransferToID=-1;

      if(data.startsWith("baseHistory")) {
        data=data.substring(11);

        intTransferFromID=CommunicationContainer.BASE_HISTORY;

        strRemove="baseHistory";
        vecRemove=cContainer.getVecBaseHistory();
        hashRemove=cContainer.getHashBaseHistory();
      }
      else if(data.startsWith("baseCurrent")) {
        data=data.substring(11);

        intTransferFromID=CommunicationContainer.BASE_CURRENT;

        strRemove="baseCurrent";
        vecRemove=cContainer.getVecBaseCurrent();
        hashRemove=cContainer.getHashBaseCurrent();
      }
      else if(data.startsWith("workerHistory")) {
        data=data.substring(13);

        intTransferFromID=CommunicationContainer.WORKER_HISTORY;

        strRemove="workerHistory";
        vecRemove=cContainer.getVecWorkerHistory();
        hashRemove=cContainer.getHashWorkerHistory();
      }
      else if(data.startsWith("workerCurrent")) {
        data=data.substring(13);

        intTransferFromID=CommunicationContainer.WORKER_CURRENT;

        strRemove="workerCurrent";
        vecRemove=cContainer.getVecWorkerCurrent();
        hashRemove=cContainer.getHashWorkerCurrent();
      }

      if(data.startsWith("baseHistory")) {
        data=data.substring(11);

        intTransferToID=CommunicationContainer.BASE_HISTORY;

        strAdd="baseHistory";
      }
      else if(data.startsWith("baseCurrent")) {
        data=data.substring(11);

        intTransferToID=CommunicationContainer.BASE_CURRENT;

        strAdd="baseCurrent";
      }
      else if(data.startsWith("workerHistory")) {
        data=data.substring(13);

        intTransferToID=CommunicationContainer.WORKER_HISTORY;

        strAdd="workerHistory";
      }
      else if(data.startsWith("workerCurrent")) {
        data=data.substring(13);

        intTransferToID=CommunicationContainer.WORKER_CURRENT;

        strAdd="workerCurrent";
      }

      try {
        String strMessage=cContainer.transferMessage(data, intTransferFromID, intTransferToID);

        Vector vecMessages=new Vector();
        for(int i=0;i<vecRemove.size();i++) {
          Object objNext=vecRemove.elementAt(i);
          vecMessages.addElement(hashRemove.get(objNext));
        }

        Iterator iter=users.iterator();
        while(iter.hasNext()) {
          ChatWebSocket user=(ChatWebSocket)iter.next();

          try {
            user.connection.sendMessage(strRemove+"clear");

            for(int i=0;i<vecRemove.size();i++) {
              Object objNext=vecRemove.elementAt(i);
              user.connection.sendMessage(strRemove+"message"+String.valueOf(objNext)+": "+String.valueOf(vecMessages.elementAt(i)));
            }

            user.connection.sendMessage(strAdd+"message"+data+": "+strMessage);
          }
          catch(Exception ex) {
          }
        }
      }
      catch(Exception ex) {
        System.out.println(String.valueOf(ex));
      }

}

      return;
    }

    Iterator iter=users.iterator();
    while(iter.hasNext()) {
      ChatWebSocket user=(ChatWebSocket)iter.next();

      try {
        user.connection.sendMessage(data);
      }
      catch(Exception ex) {
      }
    }
  }

  public void onOpen(Connection connection) {
    this.connection = connection;
    users.add(this);

synchronized(cContainer.objSync) {

    Vector vecBaseHistory=cContainer.getVecBaseHistory();
    TreeMap hashBaseHistory=cContainer.getHashBaseHistory();
    Vector vecBaseCurrent=cContainer.getVecBaseCurrent();
    TreeMap hashBaseCurrent=cContainer.getHashBaseCurrent();
    Vector vecWorkerHistory=cContainer.getVecWorkerHistory();
    TreeMap hashWorkerHistory=cContainer.getHashWorkerHistory();
    Vector vecWorkerCurrent=cContainer.getVecWorkerCurrent();
    TreeMap hashWorkerCurrent=cContainer.getHashWorkerCurrent();

    try {
      for(int i=0;i<vecBaseHistory.size();i++) {
        Object objNext=vecBaseHistory.elementAt(i);
        Object objNextM=hashBaseHistory.get(objNext);
        connection.sendMessage("baseHistory"+"message"+String.valueOf(objNext)+": "+String.valueOf(objNextM));
      }

      for(int i=0;i<vecBaseCurrent.size();i++) {
        Object objNext=vecBaseCurrent.elementAt(i);
        Object objNextM=hashBaseCurrent.get(objNext);
        connection.sendMessage("baseCurrent"+"message"+String.valueOf(objNext)+": "+String.valueOf(objNextM));
      }

      for(int i=0;i<vecWorkerHistory.size();i++) {
        Object objNext=vecWorkerHistory.elementAt(i);
        Object objNextM=hashWorkerHistory.get(objNext);
        connection.sendMessage("workerHistory"+"message"+String.valueOf(objNext)+": "+String.valueOf(objNextM));
      }

      for(int i=0;i<vecWorkerCurrent.size();i++) {
        Object objNext=vecWorkerCurrent.elementAt(i);
        Object objNextM=hashWorkerCurrent.get(objNext);
        connection.sendMessage("workerCurrent"+"message"+String.valueOf(objNext)+": "+String.valueOf(objNextM));
      }
    }
    catch(Exception ex) {
    }

}

  }

  public void onClose(int closeCode, String message) {
    users.remove(this);
  }
}